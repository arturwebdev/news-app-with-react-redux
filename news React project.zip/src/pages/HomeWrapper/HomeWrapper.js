import React from 'react'
import Header from '../../Components/Header/Header'
import Footer from '../Footer/Footer'
import { Outlet } from 'react-router-dom'

function HomeWrapper() {
  return (
    <div>
       <>
         <Header />
         <Outlet/>
         <Footer />
      </>      
    </div>
  )
}

export default HomeWrapper