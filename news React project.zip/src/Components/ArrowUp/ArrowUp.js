import React from 'react'
import './ArrowUp.css'
import { BsFillArrowUpSquareFill } from 'react-icons/bs'

function ArrowUp() {
  const goTop = () => {
    window.scrollTo(0, 0)
  }
  return (
    <div id="go-top" onClick={goTop}>
		  <p className='arrow-icon'>
        <BsFillArrowUpSquareFill />         
      </p>
	</div>   
  )
}

export default ArrowUp

