import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { setComment, setName } from '../../store/slices/inputs/inputsSlice';
import { deleteText, selectPosts, setEditId } from '../../store/slices/posts/postsSlice';
import './DeleteEdit.css'


function DeleteEdit() {
    const dispatch = useDispatch()
    const comment = useSelector(selectPosts)
    console.log(comment);
  return (
    <div>
        <span
            className="comment-delete"
            onClick={() => dispatch(deleteText(comment.id))}
            >
              Delete
            </span>
            <span
            className="comment-edit"
            onClick={() => {
                dispatch(setEditId(comment.id));
                dispatch(setName(comment.name));
                dispatch(setComment(comment.body));
              }}
            >
              Edit
        </span>
    </div>
  )
}

export default DeleteEdit