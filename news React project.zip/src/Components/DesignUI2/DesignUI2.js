import React from "react";
import { Link } from "react-router-dom";

function DesignUI2() {
  return (
    <article className="brick entry animate-this">
      <div className="entry-thumb">
        <Link to="single-standard.html" className="thumb-link">
          <img src="../../images/thumbs/diagonal-building.jpg" alt="Pattern" />
        </Link>
      </div>

      <div className="entry-text">
        <div className="entry-header">
          <div className="entry-meta">
            <span className="cat-links">
              <Link to="#">Design</Link>
              <Link to="#">UI</Link>
            </span>
          </div>

          <h1 className="entry-title">
            <Link to="single-standard.html">
              You Can See Patterns Everywhere.
            </Link>
          </h1>
        </div>
        <div className="entry-excerpt">
          Lorem ipsum Sed eiusmod esse aliqua sed incididunt aliqua incididunt
          mollit id et sit proident dolor nulla sed commodo est ad minim elit
          reprehenderit nisi officia aute incididunt velit sint in aliqua cillum
          in consequat consequat in culpa in anim.
        </div>
      </div>
    </article>
  );
}

export default DesignUI2;
